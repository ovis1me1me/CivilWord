import pandas as pd
import io 
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Request, Body
from sqlalchemy import Column, Integer, JSON  # 또는 JSONB (PostgreSQL)
# 7/21 ComplaintResponse, ComplaintCreate 추가
from app.schemas.complaint import ComplaintListResponse, FullReplySummaryResponse, ReplySummaryUpdateRequest, ComplaintResponse, ComplaintCreate
from app.schemas.reply import ReplyBase
from app.models.complaint import Complaint
from app.models.reply import Reply
from app.models.user import User 
from app.models import UserInfo 
from app.database import SessionLocal
from typing import List, Optional
from app.schemas.complaint import ComplaintSummaryResponse, ReplyStatusUpdateRequest
from app.schemas.response_message import ResponseMessage
from app.auth import get_current_user
from datetime import datetime
from fastapi.responses import StreamingResponse
import pandas as pd
from sqlalchemy import text
import re
from bllossom8b_infer.inference import generate_llm_reply  # 함수 임포트
from blossom_summarizer.summarizer import summarize_with_blossom
from typing import Any
from sqlalchemy.orm import Session
from app.schemas.complaint import ReplySummaryRequest
from app.models.complaint_history import ComplaintHistory
from fastapi import Body

router = APIRouter()

# DB 세션 의존성 주입
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


#1. 엑셀 업로드 라우터 (동적 URL보다 먼저 등록)
# [complaint]에 민원요약, 답변요약 비우고 저장
@router.post("/complaints/upload-excel", response_model=ResponseMessage)
async def upload_complaints_excel(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    user_uid = current_user.user_uid  # 또는 current_user["sub"] 타입에 따라

    contents = await file.read()
    try:
        df = pd.read_excel(io.BytesIO(contents), engine="openpyxl")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"엑셀 파일 읽기 오류: {str(e)}")

    required_columns = {"제목", "민원내용", "민원 공개 여부"}
    if not required_columns.issubset(df.columns):
        raise HTTPException(status_code=400, detail=f"다음 컬럼이 포함되어야 합니다: {required_columns}")

    for _, row in df.iterrows():
        공개여부 = str(row["민원 공개 여부"]).strip()
        if 공개여부 == "공개":
            is_public = True
        elif 공개여부 == "비공개":
            is_public = False
        else:
            raise HTTPException(
                status_code=400,
                detail=f"민원 공개 여부는 '공개' 또는 '비공개'만 허용됩니다. (입력값: {공개여부})"
            )

        complaint = Complaint(
            user_uid=user_uid,
            title=row["제목"],
            content=row["민원내용"],
            is_public=is_public,
            created_at=datetime.utcnow(),
            reply_summary={} 
        )
        db.add(complaint)

    db.commit()
    return ResponseMessage(message=f"{len(df)}건의 민원이 등록되었습니다.")

# 2. 엑셀 다운로드 라우터 
# [complaint]의 민원 관련 내용 및 [reply]의 답변 내용 엑셀로 추출
@router.get("/complaints/download-excel")
def download_complaints_excel(
    ids: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    id_list = [int(i) for i in ids.split(",") if i.isdigit()]

    if not id_list:
        raise HTTPException(status_code=400, detail="유효한 민원 ID 목록을 전달해주세요.")

    complaints = db.query(Complaint).filter(
        Complaint.user_uid == current_user.user_uid,
        Complaint.id.in_(id_list)
    ).all()

    if not complaints:
        raise HTTPException(status_code=404, detail="조회된 민원이 없습니다.")

    rows = []
    for complaint in complaints:
        reply = db.query(Reply).filter(Reply.complaint_id == complaint.id).first()
        rows.append({
            "제목": complaint.title,
            "내용": complaint.content,
            "등록일": complaint.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "공개 여부": "공개" if complaint.is_public else "비공개",
            "답변": reply.content if reply else "(답변 없음)"
        })

    df = pd.DataFrame(rows)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False, sheet_name='민원내역')

    output.seek(0)

    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=complaints.xlsx"}
    )


# 3. 민원 목록 반환 라우터
# 해당 유저 [complaint] 민원 목록 반환
@router.get("/complaints", response_model=ComplaintListResponse) 
def get_complaints(
    db: Session = Depends(get_db), 
    sort: Optional[str] = None,
    limit: Optional[int] = 10,
    skip: Optional[int] = 0, 
    current_user: str = Depends(get_current_user)
):
    query = db.query(Complaint).filter(Complaint.user_uid == current_user.user_uid)

    total = query.count()

    if sort == "created_desc":
        complaints = query.order_by(Complaint.created_at.desc()).offset(skip).limit(limit).all()
    elif sort == "created_asc":
        complaints = query.order_by(Complaint.created_at.asc()).offset(skip).limit(limit).all()
    else:
        complaints = query.order_by(Complaint.created_at.desc()).offset(skip).limit(limit).all()

    return {
        "total": total,
        "complaints": complaints
    }

# 4. 민원 반환 라우터
# id 에 맞는 [complaint] 데이터 반환
@router.get("/complaints/{id}", response_model=ComplaintResponse)
def get_complaint_by_id(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    return complaint

# 5. 민원 삭제
# 해당하는 [complaint] 및 [reply] 데이터 삭제
@router.delete("/complaints/{id}", response_model=ResponseMessage)
def delete_complaint(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 민원 존재 및 소유 확인
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    reply = db.query(Reply).filter(Reply.complaint_id == id).first()
    if reply:
        db.delete(reply)

    # 민원 삭제 (민원 요약 필드도 같이 삭제됨)
    db.delete(complaint)
    db.commit()

    return ResponseMessage(message=f"민원 {id}번과 관련된 답변 및 요약이 모두 삭제되었습니다.")

# 6. 답변 생성(LLM) 라우터 
# [complaint]의 reply_summary를 input하여 [reply] 데이터 생성
@router.post("/complaints/{id}/generate-reply", response_model=ReplyBase)
def generate_reply(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 민원 유효성 및 권한 확인
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원을 찾을 수 없거나 권한이 없습니다.")

    # 중복 답변 방지
    existing_reply = db.query(Reply).filter(Reply.complaint_id == id).first()
    if existing_reply:
        raise HTTPException(status_code=400, detail="이미 해당 민원에 대한 답변이 존재합니다.")

    # 담당자 정보 조회
    user_info = db.query(UserInfo).filter(UserInfo.user_uid == current_user.user_uid).first()
    if not user_info:
        raise HTTPException(status_code=400, detail="담당자 정보가 등록되어 있지 않습니다.")

    if not (user_info.department and user_info.name and user_info.contact):
        raise HTTPException(status_code=400, detail="담당자 정보(부서, 이름, 연락처)가 누락되었습니다.")

    # === 답변 조립 ===
    fixed_header = (
    " 평소 구정에 관심을 가져주신데 대해 감사드립니다.\n")

    fixed_summary = (
        f" 귀하께서 요청하신 민원은 \"{complaint.summary}\"에 관한 것으로 이해됩니다.\n"
    )

    # 📌 여기에서 LLM 호출
    generated_core = generate_llm_reply(complaint.reply_summary)

    fixed_footer = (
        f" 기타 궁금하신 사항은 {user_info.department}({user_info.name}, "
        f"{user_info.contact})로 문의하여 주시면 성심껏 답변드리겠습니다. 감사합니다."
    )

    reply_content = {
        "header": fixed_header,
        "summary": fixed_summary,
        "body": generated_core,
        "footer": fixed_footer
    }


    # DB 저장
    reply = Reply(
        complaint_id=id,
        content=reply_content,
        user_uid=current_user.user_uid
    )
    db.add(reply)
    complaint.reply_status = "수정중"
    db.commit()
    db.refresh(reply)

    return reply

# 7. 답변 재생산(LLM) 라우터 
# 기존 [reply]데이터 삭제 후, [complaint]의 reply_summary를 input하여 [reply] 데이터 생성
@router.post("/complaints/{id}/generate-reply-again", response_model=ReplyBase)
def generate_reply_again(
    id: int, 
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 민원 소유자 확인
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()
    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원을 찾을 수 없거나 권한이 없습니다.")

    # 기존 답변 삭제
    existing_reply = db.query(Reply).filter(Reply.complaint_id == id).first()
    if existing_reply:
        db.delete(existing_reply)
        db.commit()

    # 담당자 정보 조회
    user_info = db.query(UserInfo).filter(UserInfo.user_uid == current_user.user_uid).first()
    if not user_info or not (user_info.department and user_info.name and user_info.contact):
        raise HTTPException(status_code=400, detail="담당자 정보가 등록되어 있지 않거나 필수 항목이 누락되었습니다.")

    # 답변 내용 재조립
    fixed_header = (
    " 평소 구정에 관심을 가져주신데 대해 감사드립니다.\n"
    )
    fixed_summary = (
        f" 귀하께서 요청하신 민원은 \"{complaint.summary}\"에 관한 것으로 이해됩니다.\n"
    )
    fixed_footer = (
        f" 기타 궁금하신 사항은 {user_info.department}({user_info.name}, "
        f"{user_info.contact})로 문의하여 주시면 성심껏 답변드리겠습니다. 감사합니다."
    )
    generated_core = generate_llm_reply(complaint.reply_summary)
    reply_content = {
        "header": fixed_header,
        "summary": fixed_summary,
        "body": generated_core,
        "footer": fixed_footer
    }

    # 새 답변 저장
    new_reply = Reply(
        complaint_id=id,
        content=reply_content,
        user_uid=current_user.user_uid
    )
    db.add(new_reply)

    # 상태 갱신
    complaint.reply_status = "수정중"

    db.commit()
    db.refresh(new_reply)

    return new_reply

# 8. 응답 수정(컴플레인 아이디로 )
# 기록된 [reply]의 content 수정
@router.put("/complaints/{complaint_id}/reply", response_model=ReplyBase)
def update_reply(
    complaint_id: int,
    content: Any=Body(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 민원 소유자 확인
    complaint = db.query(Complaint).filter(
        Complaint.id == complaint_id,
        Complaint.user_uid == current_user.user_uid
    ).first()
    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    # 답변 존재 여부 확인
    reply = db.query(Reply).filter(
        Reply.complaint_id == complaint_id,
        Reply.user_uid == current_user.user_uid
    ).first()
    if not reply:
        raise HTTPException(status_code=404, detail="해당 민원에 대한 답변이 없습니다.")

    # 내용 수정
    reply.content = content
    db.commit()
    db.refresh(reply)

    return reply

# 9. 답변 검색(컴플레인 아이디로)
# 해당하는 [reply] 반환
#수정할까말까 -> 현재 하나만 반환해도 되는
@router.get("/complaints/{id}/replies", response_model=List[ReplyBase])
def get_replies(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 민원이 현재 유저 소유인지 확인
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    # 해당 민원에 대한 답변 조회
    replies = db.query(Reply).filter(
        Reply.complaint_id == id
    ).all()

    if not replies:
        raise HTTPException(status_code=404, detail="답변이 없습니다.")

    return replies

# 8. 관리자용 답변 조회
# 모든 유저의 답변 반환
@router.get("/admin/replies", response_model=List[ReplyBase])
def get_all_replies(
    db: Session = Depends(get_db)
):
    replies = db.query(Reply).all()
    return replies


# 9. 민원 요약(LLM) 라우터(없으면 생성 후 반환)
#[complaint]의 content를 input하여  LLM모델로 summary 생성
@router.get("/complaints/{id}/summary", response_model=ComplaintSummaryResponse)
def get_complaint_summary(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    # 요약이 없을 때만 생성
    if not complaint.summary:
        complaint_summary = summarize_with_blossom(complaint.content)
        complaint.summary = complaint_summary
        db.commit()
        db.refresh(complaint)
    else:
        complaint_summary = complaint.summary

    return ComplaintSummaryResponse(
        title=complaint.title,
        content=complaint.content,
        summary=complaint_summary
    )


# 10. 답변 요약 호출 라우터 
# [complaint] id 기준으로 답변 요약, 제목, 민원 반환
@router.get("/complaints/{id}/reply-summary", response_model=ComplaintSummaryResponse)
def get_reply_summary(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    if not complaint.reply_summary:
        raise HTTPException(status_code=404, detail="요약이 아직 저장되지 않았습니다.")

    return ComplaintSummaryResponse(
        title=complaint.title,
        content=complaint.content,
        summary=complaint.reply_summary
    )


@router.put("/complaints/{id}/reply-summary", response_model=ResponseMessage)
def update_reply_summary(
    id: int,
    data: ReplySummaryUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 본인 민원인지 확인
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    # 요약 저장 (수정)
    complaint.reply_summary = data.answer_summary
    db.commit()
    db.refresh(complaint)

    return ResponseMessage(message="Reply summary updated successfully!")

@router.post("/complaints/{id}/reply-summary", response_model=ResponseMessage)
def save_reply_summary(
    id: int,
    req: ReplySummaryRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원을 찾을 수 없습니다.")

    # JSON 형태 그대로 저장 (필드가 Text 또는 JSON 타입이어야 함)
    import json
    complaint.reply_summary = json.dumps(
        [item.dict() for item in req.answer_summary], 
        ensure_ascii=False
    )
    db.commit()
    return {"message": "답변요지가 저장되었습니다."}



# @router.get("/complaints/{id}/reply-options", response_model=List[ReplyBase])
# def get_reply_options(id: int, db: Session = Depends(get_db)):
#     # 해당 민원에 대한 모든 답변 조회
#     replies = db.query(Reply).filter(Reply.complaint_id == id).all()
#     if not replies:
#         raise HTTPException(status_code=404, detail="No replies found for this complaint")
    
#     return replies



@router.get("/complaints/{id}/history-similar", response_model=List[dict])
def get_similar_histories(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 1. 본인 민원 확인 및 민원요약 추출
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()

    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    query_text = complaint.summary
    if not query_text or not str(query_text).strip():
        raise HTTPException(status_code=400, detail="민원요약이 비어 있어 검색이 불가능합니다.")

    # 2. 공개된 히스토리 중 유사 민원 검색
    sql = text("""
        SELECT title, summary, reply_content
        FROM complaint_history
        WHERE is_public = TRUE
          AND summary IS NOT NULL
        ORDER BY created_at DESC
        LIMIT 2
    """)
    result = db.execute(sql).fetchall()

    # 빈 결과 처리
    if not result:
        return []

    return [
        {"title": row.title, "summary": row.summary, "content": row.reply_content}
        for row in result
    ]
    

    try:
        rows = db.execute(sql, {"query": query_text}).fetchall()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FTS 실행 실패: {str(e)}")

    if not rows:
        raise HTTPException(status_code=404, detail="유사한 공개 민원이 없습니다.")

    return [
        {
            "title": row.title,
            "summary": row.summary,
            "content": row.reply_content
        }
        for row in rows
    ]

@router.get("/admin/public-histories", response_model=List[ReplyBase])
def get_public_histories(db: Session = Depends(get_db)):
    histories = db.query(ComplaintHistory).filter(ComplaintHistory.is_public == True).limit(10).all()

    return [
        ReplyBase(
            id=history.id,
            complaint_id=history.id,  # 또는 연결된 complaint_id가 따로 있으면 그것으로 대체
            created_at=history.created_at,
            title=history.title,
            summary=history.summary or "",
            content=history.reply_content or ""
        )
        for history in histories
    ]



@router.put("/complaints/{id}/reply-status", response_model=ResponseMessage)
def update_reply_status(
    id: int,
    data: ReplyStatusUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    complaint = db.query(Complaint).filter(
        Complaint.id == id,
        Complaint.user_uid == current_user.user_uid
    ).first()
    if not complaint:
        raise HTTPException(status_code=404, detail="해당 민원이 없거나 권한이 없습니다.")

    allowed_status = {"답변전", "수정중", "답변완료"}
    if data.status not in allowed_status:
        raise HTTPException(status_code=400, detail=f"상태는 {allowed_status} 중 하나여야 합니다.")

    complaint.reply_status = data.status
    db.commit()
    db.refresh(complaint)

    return ResponseMessage(message=f"답변 상태가 '{data.status}'(으)로 변경되었습니다.")